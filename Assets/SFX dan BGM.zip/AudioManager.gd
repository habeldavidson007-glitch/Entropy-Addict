## AudioManager.gd
## Autoload singleton — manages all SFX and BGM playback.
##
## Setup: Project > Project Settings > Autoload
##   Path: res://scripts/AudioManager.gd
##   Name: AudioManager
##
## Usage:
##   AudioManager.play_sfx("sfx_step_grass")
##   AudioManager.play_bgm("bgm_plains_loop")
##   AudioManager.stop_bgm()

extends Node

# ── Volume settings (dB) ──
@export var sfx_volume_db:  float = 0.0
@export var bgm_volume_db:  float = -6.0
@export var master_volume_db: float = 0.0

# ── SFX pool size (concurrent sounds) ──
const SFX_POOL_SIZE := 8

var _sfx_players: Array[AudioStreamPlayer] = []
var _bgm_player:  AudioStreamPlayer
var _current_bgm: String = ""

# ── Audio file paths (all in res://assets/audio/) ──
const SFX_FILES := {
	# Footsteps
	"sfx_step_grass":   "res://assets/audio/sfx/sfx_step_grass.wav",
	"sfx_step_dirt":    "res://assets/audio/sfx/sfx_step_dirt.wav",
	"sfx_step_stone":   "res://assets/audio/sfx/sfx_step_stone.wav",
	"sfx_step_sand":    "res://assets/audio/sfx/sfx_step_sand.wav",
	"sfx_step_water":   "res://assets/audio/sfx/sfx_step_water.wav",
	# UI
	"sfx_ui_click":     "res://assets/audio/sfx/sfx_ui_click.wav",
	"sfx_ui_hover":     "res://assets/audio/sfx/sfx_ui_hover.wav",
	"sfx_ui_confirm":   "res://assets/audio/sfx/sfx_ui_confirm.wav",
	"sfx_ui_cancel":    "res://assets/audio/sfx/sfx_ui_cancel.wav",
	# Combat
	"sfx_attack_whoosh":"res://assets/audio/sfx/sfx_attack_whoosh.wav",
	"sfx_hit_impact":   "res://assets/audio/sfx/sfx_hit_impact.wav",
	"sfx_hit_miss":     "res://assets/audio/sfx/sfx_hit_miss.wav",
	"sfx_hit_critical": "res://assets/audio/sfx/sfx_hit_critical.wav",
	"sfx_enemy_death":  "res://assets/audio/sfx/sfx_enemy_death.wav",
	"sfx_player_death": "res://assets/audio/sfx/sfx_player_death.wav",
	# Encounter / Fog
	"sfx_enemy_alert":  "res://assets/audio/sfx/sfx_enemy_alert.wav",
	"sfx_fog_reveal":   "res://assets/audio/sfx/sfx_fog_reveal.wav",
	"sfx_level_start":  "res://assets/audio/sfx/sfx_level_start.wav",
	"sfx_level_end":    "res://assets/audio/sfx/sfx_level_end.wav",
	"sfx_turn_start":   "res://assets/audio/sfx/sfx_turn_start.wav",
	"sfx_turn_enemy":   "res://assets/audio/sfx/sfx_turn_enemy.wav",
}

const BGM_FILES := {
	"bgm_plains_loop":  "res://assets/audio/sfx/bgm_plains_loop.wav",
	"bgm_desert_loop":  "res://assets/audio/sfx/bgm_desert_loop.wav",
}

# Preloaded cache
var _sfx_cache: Dictionary = {}

func _ready() -> void:
	# Build SFX pool
	for i in SFX_POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_players.append(p)
	# BGM player
	_bgm_player = AudioStreamPlayer.new()
	_bgm_player.bus = "Music"
	_bgm_player.volume_db = bgm_volume_db
	add_child(_bgm_player)
	# Preload all SFX
	for key in SFX_FILES:
		var path: String = SFX_FILES[key]
		if ResourceLoader.exists(path):
			_sfx_cache[key] = load(path)

## Play a sound effect by key name. pitch_scale adds variation.
func play_sfx(sfx_name: String, pitch_scale: float = 1.0) -> void:
	var stream = _sfx_cache.get(sfx_name)
	if not stream:
		push_warning("AudioManager: SFX not found — " + sfx_name)
		return
	var player := _get_free_sfx_player()
	if not player: return
	player.stream = stream
	player.volume_db = sfx_volume_db
	player.pitch_scale = pitch_scale
	player.play()

## Play footstep for the tile the player just moved onto.
func play_footstep(tile_name: String) -> void:
	var sfx_key := GameData.get_footstep_sfx(tile_name)
	# Slight random pitch for variety
	var pitch := randf_range(0.92, 1.08)
	play_sfx(sfx_key, pitch)

## Start BGM — crossfades if switching tracks.
func play_bgm(bgm_name: String, fade_time: float = 1.5) -> void:
	if _current_bgm == bgm_name: return
	_current_bgm = bgm_name
	var path: String = BGM_FILES.get(bgm_name, "")
	if path.is_empty() or not ResourceLoader.exists(path):
		push_warning("AudioManager: BGM not found — " + bgm_name)
		return
	var stream = load(path)
	# Simple crossfade via tween
	var tween := create_tween()
	if _bgm_player.playing:
		tween.tween_property(_bgm_player, "volume_db", -80.0, fade_time * 0.5)
		await tween.finished
	_bgm_player.stream = stream
	_bgm_player.volume_db = -80.0
	_bgm_player.play()
	var tween2 := create_tween()
	tween2.tween_property(_bgm_player, "volume_db", bgm_volume_db, fade_time * 0.5)
	# Loop: reconnect finished signal
	if not _bgm_player.finished.is_connected(_on_bgm_finished):
		_bgm_player.finished.connect(_on_bgm_finished)

func stop_bgm(fade_time: float = 1.0) -> void:
	_current_bgm = ""
	var tween := create_tween()
	tween.tween_property(_bgm_player, "volume_db", -80.0, fade_time)
	await tween.finished
	_bgm_player.stop()

func play_bgm_for_biome(biome: String) -> void:
	var audio_data: Dictionary = GameData.BIOME_AUDIO.get(biome, GameData.BIOME_AUDIO["plains"])
	play_bgm(audio_data["ambient"])

func set_sfx_volume(linear: float) -> void:
	sfx_volume_db = linear_to_db(clamp(linear, 0.001, 1.0))

func set_bgm_volume(linear: float) -> void:
	bgm_volume_db = linear_to_db(clamp(linear, 0.001, 1.0))
	_bgm_player.volume_db = bgm_volume_db

func _get_free_sfx_player() -> AudioStreamPlayer:
	for p in _sfx_players:
		if not p.playing: return p
	# All busy — steal the first one
	return _sfx_players[0]

func _on_bgm_finished() -> void:
	# Loop the BGM
	_bgm_player.play()
