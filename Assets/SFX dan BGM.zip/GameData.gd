## GameData.gd
## Autoload singleton — add to Project > Project Settings > Autoloads
## Name it "GameData" so you can call GameData.TILES, GameData.ENEMIES etc.
##
## Setup: Project > Project Settings > Autoload
##   Path: res://scripts/GameData.gd
##   Name: GameData

extends Node

# ─────────────────────────────────────────────────────────────
# TILE METADATA
# ─────────────────────────────────────────────────────────────
# movement_cost : int   — AP cost to enter (999 = impassable)
# blocks_sight  : bool  — blocks line-of-sight for fog of war
# blocks_move   : bool  — unit cannot enter
# biome         : String — used for audio/visual variation
# spawn_weight  : int   — relative weight for procedural placement (0=never)
# description   : String — shown in UI tooltip

const TILES := {
	# ── GRASS ──
	"grass_normal": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 40, "description": "Open grassland."
	},
	"grass_damaged": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 10, "description": "Scarred earth."
	},
	"grass_path": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 8, "description": "A worn trail."
	},
	"grass_dense": {
		"movement_cost": 2, "blocks_sight": true,  "blocks_move": false,
		"biome": "plains", "spawn_weight": 12, "description": "Tall grass. Enemies may hide here."
	},
	# ── DIRT / ROAD ──
	"dirt_plain": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 15, "description": "Dry dirt ground."
	},
	"dirt_road": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 6, "description": "A packed dirt road. Fast travel."
	},
	"dirt_gravel": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 5, "description": "Loose gravel."
	},
	# ── WALLS / OBSTACLES ──
	"wall_rock": {
		"movement_cost": 999, "blocks_sight": true, "blocks_move": true,
		"biome": "any", "spawn_weight": 20, "description": "Solid stone wall."
	},
	"wall_ruins": {
		"movement_cost": 999, "blocks_sight": true, "blocks_move": true,
		"biome": "any", "spawn_weight": 8, "description": "Ancient ruins."
	},
	"wall_boulder": {
		"movement_cost": 999, "blocks_sight": true, "blocks_move": true,
		"biome": "any", "spawn_weight": 10, "description": "A massive boulder."
	},
	# ── DESERT ──
	"sand_plain": {
		"movement_cost": 2, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 40, "description": "Loose sand. Slows movement."
	},
	"sand_dunes": {
		"movement_cost": 3, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 15, "description": "Rolling dunes. Hard going."
	},
	"sand_cracked": {
		"movement_cost": 2, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 12, "description": "Dry cracked earth."
	},
	"sand_rocky": {
		"movement_cost": 2, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 10, "description": "Rocky desert floor."
	},
	# ── WATER ──
	"water_deep": {
		"movement_cost": 999, "blocks_sight": false, "blocks_move": true,
		"biome": "water", "spawn_weight": 5, "description": "Deep water. Impassable."
	},
	"water_shallow": {
		"movement_cost": 3, "blocks_sight": false, "blocks_move": false,
		"biome": "water", "spawn_weight": 4, "description": "Shallow water. Wade through slowly."
	},
}

# ─────────────────────────────────────────────────────────────
# ENEMY STAT TEMPLATES
# ─────────────────────────────────────────────────────────────
# hp            : int   — max hit points
# damage        : int   — base damage per attack
# defense       : int   — damage reduction
# move_range    : int   — tiles per turn
# attack_range  : int   — 1=melee, 2+=ranged
# detection_range: int  — tiles before enemy notices player
# xp_reward     : int   — XP granted on death
# ai_behavior   : String — "patrol"|"aggressive"|"ranged"|"guard"
# biome_tags    : Array  — biomes this enemy spawns in
# speed         : String — "fast"|"medium"|"slow"
# abilities     : Array  — special ability tags

const ENEMIES := {
	"goblin": {
		"hp": 20, "damage": 4, "defense": 0,
		"move_range": 3, "attack_range": 1,
		"detection_range": 3, "xp_reward": 10,
		"ai_behavior": "aggressive", "speed": "fast",
		"biome_tags": ["plains", "any"],
		"abilities": [],
		"description": "Quick and weak. Attacks in packs.",
		"sprite_row": 1,   # row in sprite_atlas_all_192x128.png
		"color_hint": Color(0.35, 0.67, 0.29)
	},
	"orc": {
		"hp": 60, "damage": 10, "defense": 4,
		"move_range": 2, "attack_range": 1,
		"detection_range": 4, "xp_reward": 30,
		"ai_behavior": "aggressive", "speed": "slow",
		"biome_tags": ["plains", "desert", "any"],
		"abilities": ["knockback"],
		"description": "Tough melee fighter. High defense.",
		"sprite_row": 2,
		"color_hint": Color(0.48, 0.42, 0.23)
	},
	"skeleton": {
		"hp": 30, "damage": 8, "defense": 1,
		"move_range": 2, "attack_range": 4,
		"detection_range": 5, "xp_reward": 25,
		"ai_behavior": "ranged", "speed": "medium",
		"biome_tags": ["any"],
		"abilities": ["ranged_attack"],
		"description": "Ranged archer. Keeps distance.",
		"sprite_row": 3,
		"color_hint": Color(0.87, 0.87, 0.78)
	},
	# ── Bonus enemies (art TBD) ──
	"goblin_shaman": {
		"hp": 15, "damage": 6, "defense": 0,
		"move_range": 2, "attack_range": 3,
		"detection_range": 4, "xp_reward": 35,
		"ai_behavior": "ranged", "speed": "medium",
		"biome_tags": ["plains"],
		"abilities": ["ranged_attack", "buff_allies"],
		"description": "Casts spells. Buffs nearby goblins.",
		"sprite_row": 1,
		"color_hint": Color(0.5, 0.8, 0.4)
	},
	"desert_scorpion": {
		"hp": 25, "damage": 7, "defense": 2,
		"move_range": 3, "attack_range": 1,
		"detection_range": 3, "xp_reward": 20,
		"ai_behavior": "patrol", "speed": "fast",
		"biome_tags": ["desert"],
		"abilities": ["poison"],
		"description": "Fast desert predator. Can poison.",
		"sprite_row": 1,
		"color_hint": Color(0.8, 0.6, 0.2)
	},
}

# ─────────────────────────────────────────────────────────────
# PLAYER STATS TEMPLATE
# ─────────────────────────────────────────────────────────────
const PLAYER_BASE := {
	"hp": 100, "damage": 12, "defense": 3,
	"move_range": 4, "attack_range": 1,
	"vision_range": 5,
	"xp": 0, "level": 1,
}

# XP required to reach each level
const LEVEL_XP_TABLE := [0, 50, 120, 220, 360, 540, 770, 1060, 1420, 1860]

# ─────────────────────────────────────────────────────────────
# LEVEL / SEED CONFIGURATION
# ─────────────────────────────────────────────────────────────
const LEVEL_CONFIG := {
	1: {
		"map_width": 24, "map_height": 24,
		"biome": "plains",
		"enemy_budget": 8,
		"enemy_pool": ["goblin", "goblin", "skeleton"],
		"seed": 0,  # 0 = random
		"description": "Verdant plains. Goblins patrol the paths.",
	},
	2: {
		"map_width": 28, "map_height": 28,
		"biome": "plains",
		"enemy_budget": 12,
		"enemy_pool": ["goblin", "orc", "skeleton"],
		"seed": 0,
		"description": "Ruins dot the landscape. Orcs have moved in.",
	},
	3: {
		"map_width": 32, "map_height": 32,
		"biome": "desert",
		"enemy_budget": 14,
		"enemy_pool": ["desert_scorpion", "skeleton", "goblin_shaman"],
		"seed": 0,
		"description": "The desert wastes. Scorpions and shamans roam.",
	},
}

# ─────────────────────────────────────────────────────────────
# BIOME AUDIO TAGS
# Map biome name → audio bus / ambient track key
# ─────────────────────────────────────────────────────────────
const BIOME_AUDIO := {
	"plains":  {"ambient": "bgm_plains", "footstep": "sfx_step_grass", "encounter": "sfx_encounter"},
	"desert":  {"ambient": "bgm_desert", "footstep": "sfx_step_sand",  "encounter": "sfx_encounter"},
	"water":   {"ambient": "bgm_plains", "footstep": "sfx_step_water", "encounter": "sfx_encounter"},
	"dungeon": {"ambient": "bgm_dungeon","footstep": "sfx_step_stone", "encounter": "sfx_encounter"},
}

# Surface footstep tags (keyed to tile biome for AudioStreamPlayer lookup)
const SURFACE_STEP_MAP := {
	"plains": "sfx_step_grass",
	"desert": "sfx_step_sand",
	"water":  "sfx_step_water",
	"any":    "sfx_step_stone",
}

# ─────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────────

func get_tile(tile_name: String) -> Dictionary:
	return TILES.get(tile_name, TILES["grass_normal"])

func get_enemy(enemy_name: String) -> Dictionary:
	return ENEMIES.get(enemy_name, ENEMIES["goblin"])

func get_level_config(level: int) -> Dictionary:
	return LEVEL_CONFIG.get(level, LEVEL_CONFIG[1])

func is_passable(tile_name: String) -> bool:
	return not get_tile(tile_name).get("blocks_move", false)

func get_move_cost(tile_name: String) -> int:
	return get_tile(tile_name).get("movement_cost", 1)

func blocks_sight(tile_name: String) -> bool:
	return get_tile(tile_name).get("blocks_sight", false)

func get_footstep_sfx(tile_name: String) -> String:
	var biome: String = get_tile(tile_name).get("biome", "any")
	return SURFACE_STEP_MAP.get(biome, "sfx_step_stone")

func xp_for_level(level: int) -> int:
	if level >= LEVEL_XP_TABLE.size(): return 99999
	return LEVEL_XP_TABLE[level]
