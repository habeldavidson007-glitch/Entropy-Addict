## FogOfWar.gd
## Attach to a ColorRect node that covers the full map viewport.
## The ColorRect should be on a CanvasLayer above your TileMap.
##
## Scene tree example:
##   CanvasLayer (layer = 10)
##     └── ColorRect (FogOfWar) — anchors: full rect, size = viewport
##           material: ShaderMaterial → fog_of_war.gdshader

extends ColorRect

## Size of your map in tiles
@export var map_width:  int = 32
@export var map_height: int = 32

## Reference to your TileMap node
@export var tilemap: NodePath

## Tile states
enum TileVis { HIDDEN = 0, EXPLORED = 1, VISIBLE = 2 }

var _fog_img:   Image
var _fog_tex:   ImageTexture
var _vis_grid:  Array  # Array of Array of TileVis

# Alpha values per state (stored in fog texture red channel for shader)
const ALPHA_HIDDEN   := 255
const ALPHA_EXPLORED := 160
const ALPHA_VISIBLE  :=   0

func _ready() -> void:
    _vis_grid = []
    for y in map_height:
        var row = []
        for x in map_width:
            row.append(TileVis.HIDDEN)
        _vis_grid.append(row)

    _fog_img = Image.create(map_width, map_height, false, Image.FORMAT_RGBA8)
    _fog_tex = ImageTexture.create_from_image(_fog_img)
    material.set_shader_parameter("fog_texture", _fog_tex)

    _refresh_texture()

## Call this each turn with the player's tile position and vision radius.
func reveal_around(tile_pos: Vector2i, radius: int) -> void:
    # Mark previously VISIBLE tiles as EXPLORED
    for y in map_height:
        for x in map_width:
            if _vis_grid[y][x] == TileVis.VISIBLE:
                _vis_grid[y][x] = TileVis.EXPLORED

    # Reveal tiles within radius using simple circle check
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            if dx*dx + dy*dy <= radius*radius:
                var tx = tile_pos.x + dx
                var ty = tile_pos.y + dy
                if tx >= 0 and ty >= 0 and tx < map_width and ty < map_height:
                    _vis_grid[ty][tx] = TileVis.VISIBLE

    _refresh_texture()

## Check visibility of a tile (for enemy AI / encounter logic)
func get_tile_visibility(tile_pos: Vector2i) -> TileVis:
    if tile_pos.x < 0 or tile_pos.y < 0:
        return TileVis.HIDDEN
    if tile_pos.x >= map_width or tile_pos.y >= map_height:
        return TileVis.HIDDEN
    return _vis_grid[tile_pos.y][tile_pos.x]

func is_visible(tile_pos: Vector2i) -> bool:
    return get_tile_visibility(tile_pos) == TileVis.VISIBLE

func is_explored(tile_pos: Vector2i) -> bool:
    return get_tile_visibility(tile_pos) != TileVis.HIDDEN

## Rebuild and upload the fog texture to the shader
func _refresh_texture() -> void:
    for y in map_height:
        for x in map_width:
            var vis: TileVis = _vis_grid[y][x]
            var a: int
            match vis:
                TileVis.HIDDEN:   a = ALPHA_HIDDEN
                TileVis.EXPLORED: a = ALPHA_EXPLORED
                TileVis.VISIBLE:  a = ALPHA_VISIBLE
            _fog_img.set_pixel(x, y, Color(0, 0, 0.02, a / 255.0))
    _fog_tex.update(_fog_img)

## Reveal the entire map at once (debug / cheat)
func reveal_all() -> void:
    for y in map_height:
        for x in map_width:
            _vis_grid[y][x] = TileVis.VISIBLE
    _refresh_texture()
