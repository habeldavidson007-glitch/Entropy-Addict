## HealthBar.gd
## Attach to a Control node. Uses the ui_healthbar_96x80.png sprite sheet.
##
## Scene tree:
##   HealthBar (Control, size 96x16)
##     ├── Background  (TextureRect) ← row 0 of sheet
##     ├── Fill        (TextureRect) ← row 1/2/3 depending on HP%
##     └── Frame       (TextureRect) ← row 4 of sheet (drawn on top)

extends Control

@export var max_hp: float = 100.0
@export var current_hp: float = 100.0

@onready var fill_rect: TextureRect = $Fill

# The full spritesheet (96x80 — 5 rows of 16px)
@export var sheet: Texture2D

const ROW_H = 16
const SHEET_W = 96

# Row indices
const ROW_BG     = 0
const ROW_GREEN  = 1
const ROW_YELLOW = 2
const ROW_RED    = 3
const ROW_FRAME  = 4

func _ready() -> void:
    _setup_rects()
    set_hp(current_hp)

func set_hp(new_hp: float) -> void:
    current_hp = clamp(new_hp, 0.0, max_hp)
    _update_fill()

func take_damage(amount: float) -> void:
    set_hp(current_hp - amount)

func heal(amount: float) -> void:
    set_hp(current_hp + amount)

func get_percent() -> float:
    return current_hp / max_hp

func _update_fill() -> void:
    var pct := get_percent()

    # Choose fill colour row
    var row: int
    if pct > 0.5:
        row = ROW_GREEN
    elif pct > 0.25:
        row = ROW_YELLOW
    else:
        row = ROW_RED

    # Crop fill width to match HP%
    var fill_w := int(SHEET_W * pct)
    fill_rect.texture = sheet
    fill_rect.region_enabled = true
    fill_rect.region_rect = Rect2(0, row * ROW_H, fill_w, ROW_H)
    fill_rect.size = Vector2(fill_w, ROW_H)

func _setup_rects() -> void:
    # You can call this manually or set up in the editor.
    # Assumes $Background and $Frame also use region_rect on the sheet.
    if has_node("Background"):
        var bg := $Background as TextureRect
        bg.texture = sheet
        bg.region_enabled = true
        bg.region_rect = Rect2(0, ROW_BG * ROW_H, SHEET_W, ROW_H)
    if has_node("Frame"):
        var fr := $Frame as TextureRect
        fr.texture = sheet
        fr.region_enabled = true
        fr.region_rect = Rect2(0, ROW_FRAME * ROW_H, SHEET_W, ROW_H)
