## GameData_additions.gd
## Paste these blocks into GameData.gd to extend it with
## the new enemies and extra tile variants.
## ──────────────────────────────────────────────────────────

# ── ADD TO const TILES (after "desert_bones" entry) ────────

## Extra tile variants
const TILES_EXTRA := {
	"grass_burnt": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 4, "description": "Scorched earth. Smells of ash."
	},
	"grass_flowers": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 8, "description": "Pretty wildflowers."
	},
	"dirt_mud": {
		"movement_cost": 2, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 6, "description": "Sticky mud. Hard to cross."
	},
	"sand_oasis": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 3, "description": "A rare oasis. Fresh water."
	},
	"wall_vines": {
		"movement_cost": 999, "blocks_sight": true, "blocks_move": true,
		"biome": "plains", "spawn_weight": 5, "description": "Vine-covered stone. Impassable."
	},
	"water_lily": {
		"movement_cost": 999, "blocks_sight": false, "blocks_move": true,
		"biome": "water", "spawn_weight": 3, "description": "Water with lily pads. Still deep."
	},
	"grass_ruins_ground": {
		"movement_cost": 1, "blocks_sight": false, "blocks_move": false,
		"biome": "plains", "spawn_weight": 5, "description": "Ruins reclaimed by nature."
	},
	"desert_bones": {
		"movement_cost": 2, "blocks_sight": false, "blocks_move": false,
		"biome": "desert", "spawn_weight": 4, "description": "Bones bleached by the sun."
	},
}

# ── ADD TO const ENEMIES ────────────────────────────────────

const ENEMIES_NEW := {
	"dark_mage": {
		"hp": 35, "damage": 14, "defense": 1,
		"move_range": 2, "attack_range": 5,
		"detection_range": 6, "xp_reward": 45,
		"ai_behavior": "ranged", "speed": "medium",
		"biome_tags": ["any"],
		"abilities": ["ranged_attack", "aoe_cast", "buff_self"],
		"description": "Casts powerful spells from range. Fragile up close.",
		"sprite_sheet": "res://assets/characters/sprite_mage_192x32.png",
		"sprite_row": 0,
		"color_hint": Color(0.47, 0.20, 0.67),
		"vfx_attack": "hit_critical",
		"vfx_death":  "death",
		"sfx_attack": "sfx_attack_whoosh",
		"sfx_death":  "sfx_enemy_death",
	},
	"troll": {
		"hp": 120, "damage": 18, "defense": 8,
		"move_range": 1, "attack_range": 1,
		"detection_range": 3, "xp_reward": 80,
		"ai_behavior": "aggressive", "speed": "slow",
		"biome_tags": ["plains", "any"],
		"abilities": ["knockback", "regenerate"],
		"description": "Massive and nearly unstoppable. Regenerates HP each turn.",
		"sprite_sheet": "res://assets/characters/sprite_troll_192x32.png",
		"sprite_row": 0,
		"color_hint": Color(0.31, 0.55, 0.31),
		"vfx_attack": "hit_impact",
		"vfx_death":  "death",
		"sfx_attack": "sfx_hit_impact",
		"sfx_death":  "sfx_enemy_death",
	},
	"desert_scorpion": {
		"hp": 25, "damage": 7, "defense": 2,
		"move_range": 3, "attack_range": 1,
		"detection_range": 3, "xp_reward": 20,
		"ai_behavior": "patrol", "speed": "fast",
		"biome_tags": ["desert"],
		"abilities": ["poison"],
		"description": "Fast desert predator. Sting applies poison for 3 turns.",
		"sprite_sheet": "res://assets/characters/sprite_scorpion_192x32.png",
		"sprite_row": 0,
		"color_hint": Color(0.71, 0.51, 0.16),
		"vfx_attack": "poison",
		"vfx_death":  "death",
		"sfx_attack": "sfx_hit_impact",
		"sfx_death":  "sfx_enemy_death",
	},
}

# ── VFX MAPPING — add to GameData for easy lookup ──────────

const VFX_MAP := {
	"attack_normal":   "hit_impact",
	"attack_critical": "hit_critical",
	"attack_miss":     "",            # no vfx for miss (just sfx)
	"attack_ranged":   "hit_impact",
	"heal":            "heal",
	"death_unit":      "death",
	"fog_reveal":      "fog_reveal",
	"enemy_alert":     "alert",
	"poison_tick":     "poison",
	"footstep":        "footprint",
}

# ── Helper (merge into GameData helpers section) ─────────────

func get_vfx_for_event(event: String) -> String:
	return VFX_MAP.get(event, "")

func get_all_tiles() -> Dictionary:
	## Returns merged base + extra tile dictionaries
	var merged := TILES.duplicate()
	merged.merge(TILES_EXTRA)
	return merged

func get_all_enemies() -> Dictionary:
	var merged := ENEMIES.duplicate()
	merged.merge(ENEMIES_NEW)
	return merged
