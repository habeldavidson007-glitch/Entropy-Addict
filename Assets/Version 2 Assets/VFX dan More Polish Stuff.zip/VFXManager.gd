## VFXManager.gd
## Autoload singleton — spawns and manages all VFX sprite animations.
##
## Setup: Project > Project Settings > Autoload
##   Path: res://scripts/VFXManager.gd
##   Name: VFXManager
##
## Usage:
##   VFXManager.play("hit_impact",  world_position)
##   VFXManager.play("hit_critical", world_position)
##   VFXManager.play("heal",         world_position)
##   VFXManager.play("death",        world_position)
##   VFXManager.play("fog_reveal",   world_position)
##   VFXManager.play("alert",        world_position)
##   VFXManager.play("poison",       world_position)

extends Node

## VFX sheet definitions
## sheet   : texture path
## frames  : number of animation frames
## fps     : playback speed
## hframes : horizontal frames in sheet
## offset  : draw offset so the effect centres on the target position
const VFX_DATA := {
	"hit_impact": {
		"sheet": "res://assets/vfx/vfx_hit_impact_192x32.png",
		"frames": 6, "fps": 18, "hframes": 6, "offset": Vector2(-16, -16)
	},
	"hit_critical": {
		"sheet": "res://assets/vfx/vfx_hit_critical_192x32.png",
		"frames": 6, "fps": 16, "hframes": 6, "offset": Vector2(-16, -16)
	},
	"heal": {
		"sheet": "res://assets/vfx/vfx_heal_192x32.png",
		"frames": 6, "fps": 12, "hframes": 6, "offset": Vector2(-16, -28)
	},
	"death": {
		"sheet": "res://assets/vfx/vfx_death_256x32.png",
		"frames": 8, "fps": 14, "hframes": 8, "offset": Vector2(-16, -16)
	},
	"fog_reveal": {
		"sheet": "res://assets/vfx/vfx_fog_reveal_192x32.png",
		"frames": 6, "fps": 16, "hframes": 6, "offset": Vector2(-16, -16)
	},
	"footprint": {
		"sheet": "res://assets/vfx/vfx_footprint_128x32.png",
		"frames": 4, "fps":  8, "hframes": 4, "offset": Vector2(-16, -16)
	},
	"alert": {
		"sheet": "res://assets/vfx/vfx_alert_160x32.png",
		"frames": 5, "fps": 14, "hframes": 5, "offset": Vector2(-16, -32)
	},
	"poison": {
		"sheet": "res://assets/vfx/vfx_poison_160x32.png",
		"frames": 5, "fps": 12, "hframes": 5, "offset": Vector2(-16, -28)
	},
}

## Pool of reusable AnimatedSprite2D nodes
const POOL_SIZE := 16
var _pool: Array[AnimatedSprite2D] = []

func _ready() -> void:
	for i in POOL_SIZE:
		var sprite := AnimatedSprite2D.new()
		sprite.visible = false
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		add_child(sprite)
		_pool.append(sprite)
		sprite.animation_finished.connect(_on_vfx_done.bind(sprite))

## Spawn a VFX at a world position. Returns the sprite node (or null if pool full).
func play(vfx_name: String, world_pos: Vector2) -> AnimatedSprite2D:
	var data: Dictionary = VFX_DATA.get(vfx_name, {})
	if data.is_empty():
		push_warning("VFXManager: unknown effect — " + vfx_name)
		return null

	var sprite := _get_free_sprite()
	if not sprite: return null

	# Build SpriteFrames on the fly (cache could be added for performance)
	var tex: Texture2D = load(data["sheet"])
	if not tex: return null

	var frames := SpriteFrames.new()
	frames.add_animation("play")
	frames.set_animation_speed("play", data["fps"])
	frames.set_animation_loop("play", false)

	var hf: int = data["hframes"]
	var frame_w: int = tex.get_width() / hf
	var frame_h: int = tex.get_height()
	for fi in data["frames"]:
		var atlas := AtlasTexture.new()
		atlas.atlas = tex
		atlas.region = Rect2(fi * frame_w, 0, frame_w, frame_h)
		frames.add_frame("play", atlas)

	sprite.sprite_frames = frames
	sprite.global_position = world_pos + data.get("offset", Vector2.ZERO)
	sprite.visible = true
	sprite.play("play")
	return sprite

## Play VFX then call a callback when done.
func play_with_callback(vfx_name: String, world_pos: Vector2, callback: Callable) -> void:
	var sprite := play(vfx_name, world_pos)
	if sprite:
		sprite.animation_finished.connect(callback, CONNECT_ONE_SHOT)

func _get_free_sprite() -> AnimatedSprite2D:
	for s in _pool:
		if not s.visible: return s
	return null  # pool exhausted

func _on_vfx_done(sprite: AnimatedSprite2D) -> void:
	sprite.visible = false
	sprite.sprite_frames = null
