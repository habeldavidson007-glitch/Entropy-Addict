# Entropy Addict — Sound Specification
# Semua sound yang dibutuhkan, beserta spesifikasi untuk mencarinya
# Format target: .ogg, mono untuk SFX, stereo untuk BGM/Ambience
# Loop: BGM dan Ambience harus loop seamlessly

---

## LISENSI YANG AMAN UNTUK PENGGUNAAN KOMERSIAL

Gunakan hanya sound dengan lisensi berikut:
- CC0 (Creative Commons Zero) — tidak perlu attribution, bebas komersial
- CC BY 4.0 — bebas komersial, cukup tulis nama pembuatnya di credits game
- MIT / Apache 2.0 — bebas komersial

HINDARI:
- CC NC (Non-Commercial) — tidak boleh untuk game berbayar
- CC ND (No Derivatives) — tidak boleh dimodifikasi
- "Free for personal use" — tidak termasuk komersial
- Royalty-free tapi berbayar per-project — baca lisensinya dulu

---

## SUMBER TERPERCAYA

### 1. Freesound.org — https://freesound.org
Cara filter aman: saat search, centang "Creative Commons 0" di sidebar Licenses
Terbaik untuk: SFX individual (langkah, impact, suara alam)

### 2. OpenGameArt.org — https://opengameart.org
Filter: pilih "CC0" atau "CC-BY" di License dropdown
Terbaik untuk: BGM loop, ambience tracks, complete SFX packs

### 3. itch.io (free audio packs) — https://itch.io/game-assets/free/tag-audio
Filter: Free, check lisensi di halaman setiap pack
Terbaik untuk: BGM dan SFX packs yang sudah di-curate untuk game

### 4. Kenney.nl — https://kenney.nl/assets?q=audio
Semua asset Kenney adalah CC0. Tidak perlu cek lisensi.
Terbaik untuk: UI sounds, impact sounds, footsteps

### 5. Pixabay.com/sound-effects — https://pixabay.com/sound-effects
Semua sound CC0. Langsung download.
Terbaik untuk: alam, angin, api, air

---

## SOUND SPEC LIST

### SFX — MOVEMENT (4 files)

footstep_dirt.ogg
  Deskripsi : Langkah di tanah kering padat — khas Ashveld Flats
  Durasi    : 0.2–0.3 detik, mono
  Character : Dry crunch, flat ground, no echo
  Freesound : search "footstep gravel dry" atau "dirt footstep"
  Kenney    : Impact Sounds pack atau RPG Audio pack

footstep_clay.ogg
  Deskripsi : Langkah di clay basah — wet clay patches Ch.001
  Durasi    : 0.2–0.3 detik, mono
  Character : Slightly wet, heavier than dirt
  Freesound : search "footstep mud soft"

footstep_stone.ogg
  Deskripsi : Langkah di batu — Iron Chorus region
  Durasi    : 0.2–0.3 detik, mono
  Character : Hard surface, slight echo
  Freesound : search "footstep stone floor"

footstep_grass.ogg
  Deskripsi : Langkah di scrub grass — Ashveld scrub patches
  Durasi    : 0.2–0.3 detik, mono
  Character : Soft rustle
  Freesound : search "footstep grass soft"

---

### SFX — COMBAT PLAYER (8 files)

hit_impact.ogg
  Deskripsi : Physical impact — punch/hit connecting
  Durasi    : 0.1–0.2 detik, mono
  Character : Blunt, physical. Not flashy. This is Unarmed combat.
  Freesound : search "punch impact dull" atau "hit thud"
  Kenney    : Impact Sounds

hit_flesh.ogg
  Deskripsi : Softer layer under hit_impact — played simultaneously
  Durasi    : 0.1 detik, mono
  Character : Softer, body-contact quality
  Freesound : search "body hit soft"

gap_strike.ogg
  Deskripsi : Jarger's precise Striker entry — faster whoosh + impact
  Durasi    : 0.3 detik, mono
  Character : Swift air movement + sharp contact. More decisive than hit_impact.
  Freesound : search "whoosh fast punch"

breakthrough.ogg
  Deskripsi : Renk's Breaker special — full body drive through
  Durasi    : 0.4 detik, mono
  Character : Heavy, sustained impact. More mass than gap_strike.
  Freesound : search "heavy impact crash"

hold_the_line.ogg
  Deskripsi : Renk bracing — weight planted sound
  Durasi    : 0.3 detik, mono
  Character : Feet planting, low thud
  Freesound : search "heavy step plant"

withdraw_call.ogg
  Deskripsi : Branec's withdrawal signal — distinctive, clear
  Durasi    : 0.4 detik, mono
  Character : Short, commanding. Not a shout. A clear sound. Single tone.
  Freesound : search "signal bell short" atau "alert tone"
  Note      : Bisa pakai single bell strike yang pendek

player_hurt.ogg
  Deskripsi : Player character taking damage
  Durasi    : 0.3 detik, mono
  Character : Sharp intake of breath + impact. Not dramatic — Jarger does not exclaim.
  Freesound : search "grunt hurt short"

player_ko.ogg
  Deskripsi : Party member KO
  Durasi    : 0.5 detik, mono
  Character : Heavy fall, sustained
  Freesound : search "body fall ground heavy"

---

### SFX — ENEMIES (6 files)

hyena_yip.ogg
  Deskripsi : Hyena idle/pack communication — irregular yipping
  Durasi    : 0.3–0.5 detik, mono
  Character : "The kind of sound that did not have a clean referent" — Ch.001
  Freesound : search "hyena vocalization" atau "hyena laugh"
  Note      : Banyak tersedia CC0 di Freesound dari rekaman alam

hyena_growl.ogg
  Deskripsi : Hyena aggro — deep threat sound
  Durasi    : 0.5 detik, mono
  Freesound : search "hyena growl"

hyena_attack.ogg
  Deskripsi : Hyena lunge/bite
  Durasi    : 0.3 detik, mono
  Freesound : search "animal bite snap" atau "dog snap"

raider_shout.ogg
  Deskripsi : Raider aggro shout — wordless
  Durasi    : 0.4 detik, mono
  Character : Human, aggressive, not articulate
  Freesound : search "male shout aggressive short"

enemy_hurt.ogg
  Deskripsi : Enemy taking damage
  Durasi    : 0.2 detik, mono
  Freesound : search "grunt short"

enemy_ko.ogg
  Deskripsi : Enemy defeated
  Durasi    : 0.4 detik, mono
  Freesound : search "fall thud body"

---

### SFX — ENVIRONMENT (5 files)

fire_crackle.ogg
  Deskripsi : Campfire crackle — single crack/pop
  Durasi    : 0.2–0.4 detik, mono
  Freesound : search "fire crackle single" atau "campfire pop"
  Pixabay   : search "fire crackle"

fire_ember.ogg
  Deskripsi : Ember floating up — soft hiss
  Durasi    : 0.3 detik, mono
  Freesound : search "ember spark fly"

water_ripple.ogg
  Deskripsi : Small water disturbance — pool ripple
  Durasi    : 0.4 detik, mono
  Freesound : search "water drip ripple" atau "water surface small"

rain_drop.ogg
  Deskripsi : Individual rain drop on flat ground — Ch.002 rain
  Durasi    : 0.1 detik, mono
  Freesound : search "raindrop flat surface"

forge_hammer.ogg
  Deskripsi : Iron Chorus forge — hammer on metal
  Durasi    : 0.3 detik, mono
  Character : "The hammering sound carries further than it should" — Ch.062
  Freesound : search "hammer metal anvil"

---

### SFX — UI / SYSTEM (9 files)

sysnotif_appear.ogg
  Deskripsi : [ SYSTEM ] notification appear sound
  Durasi    : 0.3 detik, mono
  Character : Cold. Administrative. Short. NOT a fanfare.
              Jarger: "The system did not care about any of that."
  Freesound : search "notification beep short" atau "terminal beep"
  Note      : Pilih yang paling dingin dan paling tidak emosional

inventory_unlock.ogg
  Deskripsi : Inventory system unlocking — Ch.028
  Durasi    : 0.6 detik, mono
  Character : Mechanical unlock. Satisfying but not triumphant.
  Freesound : search "lock open mechanical" atau "unlock click"

fate_reveal.ogg
  Deskripsi : Fate Title generating — Ch.015 Sovereign Tide
  Durasi    : 1.0–1.5 detik, mono
  Character : Something shifting. Not a victory sound. Something becoming true.
  Freesound : search "shimmer tone soft" atau "reveal chime"
  Note      : Pilih yang lebih subtle dari yang kamu instingtif pilih

call_identify.ogg
  Deskripsi : Call identified — Jarger reads someone's Call
  Durasi    : 0.4 detik, mono
  Character : Quiet recognition. Very subtle.
  Freesound : search "soft chime single" atau "bell soft short"

menu_select.ogg
  Deskripsi : Cursor movement in menu
  Durasi    : 0.1 detik, mono
  Kenney    : UI Audio pack (CC0)

menu_confirm.ogg
  Deskripsi : Confirm selection
  Durasi    : 0.2 detik, mono
  Kenney    : UI Audio pack

menu_back.ogg
  Deskripsi : Back/cancel
  Durasi    : 0.2 detik, mono
  Kenney    : UI Audio pack

codex_open.ogg
  Deskripsi : Opening Codex panel
  Durasi    : 0.3 detik, mono
  Character : Paper/document sound, very light
  Freesound : search "paper rustle soft"

dialogue_advance.ogg
  Deskripsi : Text advance in dialogue box
  Durasi    : 0.1 detik, mono
  Kenney    : UI Audio pack (click sound)

---

### SFX — WORLD (2 files)

build_place.ogg
  Deskripsi : Structure placed — grain store, cache point
  Durasi    : 0.4 detik, mono
  Freesound : search "wood place thud" atau "object set down"

stage_advance.ogg
  Deskripsi : Civilisation stage transition (Nomad → Tribe, dll)
  Durasi    : 0.8 detik, stereo
  Character : Quiet, significant. Not celebratory. Something is now real.
  Freesound : search "ambient tone shift" atau "deep tone single"

---

### BGM — 7 tracks + 2 stings

ashveld_day.ogg
  Deskripsi : Main world theme — daytime Ashveld Flats exploration
  Durasi    : 2–4 menit, loop seamless, stereo
  Character : Dry, open, melancholic. Sparse instrumentation.
              Drone + sparse percussion. No resolution.
              "A survival story dressed in the clothes of a power fantasy."
  OpenGameArt: search tag "ambient" + "CC0" + "sparse"
  itch.io   : search "ambient RPG soundtrack free"

ashveld_night.ogg
  Deskripsi : Night exploration — same world, different register
  Durasi    : 2–3 menit, loop, stereo
  Character : Darker, quieter. Tension without action.

tribe_camp.ogg
  Deskripsi : Tribe camp / safe zone BGM
  Durasi    : 2–3 menit, loop, stereo
  Character : Warmer than ashveld_day but not comfortable.
              Something being built. Not arrived yet.

iron_chorus.ogg
  Deskripsi : Iron Chorus region — mountain, forge presence
  Durasi    : 2–3 menit, loop, stereo
  Character : Heavy, industrial undercurrent. Low drones.
              The hammering sound implied, not literal.

caldenmere.ogg
  Deskripsi : River Delta — Caldenmere
  Durasi    : 2–3 menit, loop, stereo
  Character : Water, movement, commerce. More complex than Ashveld.

combat_standard.ogg
  Deskripsi : Standard combat BGM
  Durasi    : 1–2 menit, loop, stereo
  Character : Tense, rhythmic, not heroic.

combat_tense.ogg
  Deskripsi : High-stakes combat (organized force)
  Durasi    : 1–2 menit, loop, stereo
  Character : More urgent than combat_standard.

fate_title.ogg (sting)
  Deskripsi : Short musical moment — Ch.015 Sovereign Tide
  Durasi    : 20–40 detik, NO loop, stereo
  Character : Not triumphant. Uncertain. Something is true now.
              "He finishes his push-ups."

inventory_unlock_sting.ogg (sting)
  Deskripsi : Inventory unlock musical moment — Ch.028
  Durasi    : 10–15 detik, NO loop, stereo
  Character : Mechanical satisfaction. Quiet click of things fitting.

---

### AMBIENCE — 7 tracks

wind_flats.ogg
  Deskripsi : Ashveld wind, daytime — constant background
  Durasi    : 1–2 menit, seamless loop, stereo
  Character : Open, dry, exposed. Always present in the Flats.
  Pixabay   : search "wind open field"
  Freesound : search "wind open flat CC0"

wind_flats_night.ogg
  Deskripsi : Wind at night — quieter, more detail
  Durasi    : 1–2 menit, seamless loop, stereo

campfire_ambient.ogg
  Deskripsi : Active campfire ambience — crackling loop
  Durasi    : 1 menit, seamless loop, stereo
  Freesound : search "campfire loop CC0"
  Pixabay   : search "campfire crackling"

forge_room.ogg
  Deskripsi : Iron Chorus forge interior ambience
  Durasi    : 1–2 menit, loop, stereo
  Character : Bellows, distant hammer, heat hiss
  Freesound : search "forge ambient" atau "blacksmith workshop"

rain_light.ogg
  Deskripsi : Light rain — Ch.002 rain scene
  Durasi    : 1–2 menit, loop, stereo
  Freesound : search "rain soft loop CC0"
  Pixabay   : search "rain light"

river_delta.ogg
  Deskripsi : Caldenmere water ambience
  Durasi    : 1–2 menit, loop, stereo
  Freesound : search "river water flowing loop"

mountain_wind.ogg
  Deskripsi : Iron Chorus exterior — high altitude wind
  Durasi    : 1–2 menit, loop, stereo
  Freesound : search "mountain wind loop"

---

## CONVERSION TIPS

Setelah download, semua file perlu dikonversi ke .ogg jika belum:
- Gratis: Audacity (https://www.audacityteam.org) → Export as OGG
- Online: https://convertio.co/mp3-ogg/ (CC0 files aman diupload)

Settings untuk Godot:
- SFX mono: 44100 Hz, mono, OGG quality 5
- BGM stereo: 44100 Hz, stereo, OGG quality 7
- Ambience: 44100 Hz, stereo, OGG quality 6, loop points set

---

## CREDITS TEMPLATE
Jika menggunakan CC-BY (perlu attribution), tambahkan di credits game:

"Audio Credits:
[Sound Name] by [Author] — Freesound.org — CC BY 4.0
[Sound Name] by [Author] — OpenGameArt.org — CC BY 3.0
UI sounds by Kenney (kenney.nl) — CC0"

CC0 tidak perlu dicantumkan tapi tidak dilarang jika ingin menghargai pembuat.
