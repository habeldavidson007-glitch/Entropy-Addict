# AudioManager.gd
# Autoload — tambahkan ke Project Settings > Autoloads sebagai "Audio"
# Handles semua audio di game: BGM, SFX, Ambience
# Usage: Audio.play_sfx("footstep_dirt")
#        Audio.play_bgm("ashveld_day")
#        Audio.play_ambience("wind_flats")
extends Node

# ── Bus names (harus match dengan Audio Bus Layout di Godot) ──────────────────
const BUS_MASTER   = "Master"
const BUS_BGM      = "BGM"
const BUS_SFX      = "SFX"
const BUS_AMBIENCE = "Ambience"
const BUS_UI       = "UI"

# ── Volume defaults (0.0 = silent, 1.0 = full) ───────────────────────────────
var vol_master   : float = 1.0
var vol_bgm      : float = 0.7
var vol_sfx      : float = 0.9
var vol_ambience : float = 0.5
var vol_ui       : float = 0.8

# ── Audio players ─────────────────────────────────────────────────────────────
@onready var _bgm_player   : AudioStreamPlayer = $BGMPlayer
@onready var _amb_player   : AudioStreamPlayer = $AmbiencePlayer
@onready var _ui_player    : AudioStreamPlayer = $UIPlayer

# SFX pool — multiple players for overlapping sounds
var _sfx_pool     : Array[AudioStreamPlayer] = []
const SFX_POOL_SIZE = 8

# ── Sound registry — all keys map to res:// paths ────────────────────────────
# File format: .ogg recommended for Godot 4 (smaller, loops cleanly)
# Fallback: .wav works too but larger file size
const SFX : Dictionary = {
    # Movement
    "footstep_dirt"      : "res://audio/sfx/movement/footstep_dirt.ogg",
    "footstep_clay"      : "res://audio/sfx/movement/footstep_clay.ogg",
    "footstep_stone"     : "res://audio/sfx/movement/footstep_stone.ogg",
    "footstep_grass"     : "res://audio/sfx/movement/footstep_grass.ogg",

    # Combat — player
    "hit_impact"         : "res://audio/sfx/combat/hit_impact.ogg",
    "hit_flesh"          : "res://audio/sfx/combat/hit_flesh.ogg",
    "gap_strike"         : "res://audio/sfx/combat/gap_strike.ogg",
    "breakthrough"       : "res://audio/sfx/combat/breakthrough.ogg",
    "hold_the_line"      : "res://audio/sfx/combat/hold_the_line.ogg",
    "withdraw_call"      : "res://audio/sfx/combat/withdraw_call.ogg",
    "player_hurt"        : "res://audio/sfx/combat/player_hurt.ogg",
    "player_ko"          : "res://audio/sfx/combat/player_ko.ogg",

    # Combat — enemies
    "hyena_yip"          : "res://audio/sfx/enemies/hyena_yip.ogg",
    "hyena_growl"        : "res://audio/sfx/enemies/hyena_growl.ogg",
    "hyena_attack"       : "res://audio/sfx/enemies/hyena_attack.ogg",
    "raider_shout"       : "res://audio/sfx/enemies/raider_shout.ogg",
    "enemy_hurt"         : "res://audio/sfx/enemies/enemy_hurt.ogg",
    "enemy_ko"           : "res://audio/sfx/enemies/enemy_ko.ogg",

    # Environment
    "fire_crackle"       : "res://audio/sfx/environment/fire_crackle.ogg",
    "fire_ember"         : "res://audio/sfx/environment/fire_ember.ogg",
    "water_ripple"       : "res://audio/sfx/environment/water_ripple.ogg",
    "rain_drop"          : "res://audio/sfx/environment/rain_drop.ogg",
    "forge_hammer"       : "res://audio/sfx/environment/forge_hammer.ogg",

    # UI / System
    "sysnotif_appear"    : "res://audio/sfx/ui/sysnotif_appear.ogg",
    "inventory_unlock"   : "res://audio/sfx/ui/inventory_unlock.ogg",
    "fate_reveal"        : "res://audio/sfx/ui/fate_reveal.ogg",
    "call_identify"      : "res://audio/sfx/ui/call_identify.ogg",
    "menu_select"        : "res://audio/sfx/ui/menu_select.ogg",
    "menu_confirm"       : "res://audio/sfx/ui/menu_confirm.ogg",
    "menu_back"          : "res://audio/sfx/ui/menu_back.ogg",
    "codex_open"         : "res://audio/sfx/ui/codex_open.ogg",
    "dialogue_advance"   : "res://audio/sfx/ui/dialogue_advance.ogg",

    # Tribe / Structure
    "build_place"        : "res://audio/sfx/world/build_place.ogg",
    "stage_advance"      : "res://audio/sfx/world/stage_advance.ogg",
}

const BGM : Dictionary = {
    # World exploration
    "ashveld_day"        : "res://audio/bgm/ashveld_day.ogg",
    "ashveld_night"      : "res://audio/bgm/ashveld_night.ogg",
    "tribe_camp"         : "res://audio/bgm/tribe_camp.ogg",
    "iron_chorus"        : "res://audio/bgm/iron_chorus.ogg",
    "caldenmere"         : "res://audio/bgm/caldenmere.ogg",

    # Combat
    "combat_standard"    : "res://audio/bgm/combat_standard.ogg",
    "combat_tense"       : "res://audio/bgm/combat_tense.ogg",

    # Story moments
    "fate_title"         : "res://audio/bgm/fate_title.ogg",
    "inventory_unlock_sting" : "res://audio/bgm/inventory_unlock_sting.ogg",
}

const AMBIENCE : Dictionary = {
    "wind_flats"         : "res://audio/ambience/wind_flats.ogg",
    "wind_flats_night"   : "res://audio/ambience/wind_flats_night.ogg",
    "campfire_ambient"   : "res://audio/ambience/campfire_ambient.ogg",
    "forge_room"         : "res://audio/ambience/forge_room.ogg",
    "rain_light"         : "res://audio/ambience/rain_light.ogg",
    "river_delta"        : "res://audio/ambience/river_delta.ogg",
    "mountain_wind"      : "res://audio/ambience/mountain_wind.ogg",
}

# ── Lifecycle ─────────────────────────────────────────────────────────────────
func _ready() -> void:
    _build_sfx_pool()
    _apply_volumes()

func _build_sfx_pool() -> void:
    for i in range(SFX_POOL_SIZE):
        var p := AudioStreamPlayer.new()
        p.bus = BUS_SFX
        add_child(p)
        _sfx_pool.append(p)

func _apply_volumes() -> void:
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(BUS_MASTER),
        linear_to_db(vol_master))
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(BUS_BGM),
        linear_to_db(vol_bgm))
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(BUS_SFX),
        linear_to_db(vol_sfx))
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(BUS_AMBIENCE),
        linear_to_db(vol_ambience))
    AudioServer.set_bus_volume_db(
        AudioServer.get_bus_index(BUS_UI),
        linear_to_db(vol_ui))

# ── SFX ───────────────────────────────────────────────────────────────────────
func play_sfx(key: String,
              pitch_variation: float = 0.0,
              volume_db: float = 0.0) -> void:
    if not SFX.has(key):
        return
    var stream := load(SFX[key]) as AudioStream
    if stream == null:
        return
    var player := _get_free_sfx_player()
    if player == null:
        return
    player.stream             = stream
    player.pitch_scale        = 1.0 + randf_range(-pitch_variation, pitch_variation)
    player.volume_db          = volume_db
    player.play()

func _get_free_sfx_player() -> AudioStreamPlayer:
    for p in _sfx_pool:
        if not p.playing:
            return p
    # All busy — reuse oldest (first in pool)
    _sfx_pool[0].stop()
    return _sfx_pool[0]

# ── BGM ───────────────────────────────────────────────────────────────────────
var _current_bgm : String = ""

func play_bgm(key: String, fade_duration: float = 1.5) -> void:
    if _current_bgm == key:
        return
    if not BGM.has(key):
        return
    _current_bgm = key
    var stream := load(BGM[key]) as AudioStream
    if stream == null:
        return
    if _bgm_player.playing and fade_duration > 0.0:
        _crossfade_bgm(stream, fade_duration)
    else:
        _bgm_player.stream = stream
        _bgm_player.play()

func _crossfade_bgm(new_stream: AudioStream, duration: float) -> void:
    var tween := create_tween()
    tween.tween_property(_bgm_player, "volume_db",
        -80.0, duration * 0.5)
    tween.tween_callback(func():
        _bgm_player.stream = new_stream
        _bgm_player.volume_db = -80.0
        _bgm_player.play()
    )
    tween.tween_property(_bgm_player, "volume_db",
        linear_to_db(vol_bgm), duration * 0.5)

func stop_bgm(fade_duration: float = 1.0) -> void:
    _current_bgm = ""
    if fade_duration > 0.0:
        var tween := create_tween()
        tween.tween_property(_bgm_player, "volume_db", -80.0, fade_duration)
        tween.tween_callback(_bgm_player.stop)
    else:
        _bgm_player.stop()

# ── Ambience ──────────────────────────────────────────────────────────────────
var _current_amb : String = ""

func play_ambience(key: String, fade_duration: float = 2.0) -> void:
    if _current_amb == key:
        return
    if not AMBIENCE.has(key):
        return
    _current_amb = key
    var stream := load(AMBIENCE[key]) as AudioStream
    if stream == null:
        return
    _amb_player.stream = stream
    _amb_player.play()
    var tween := create_tween()
    _amb_player.volume_db = -80.0
    tween.tween_property(_amb_player, "volume_db",
        linear_to_db(vol_ambience), fade_duration)

func stop_ambience(fade_duration: float = 2.0) -> void:
    _current_amb = ""
    var tween := create_tween()
    tween.tween_property(_amb_player, "volume_db", -80.0, fade_duration)
    tween.tween_callback(_amb_player.stop)

# ── UI sounds ─────────────────────────────────────────────────────────────────
func play_ui(key: String) -> void:
    if not SFX.has(key):
        return
    var stream := load(SFX[key]) as AudioStream
    if stream == null:
        return
    _ui_player.stream = stream
    _ui_player.play()

# ── Volume controls (for settings menu) ──────────────────────────────────────
func set_volume_master(v: float)   -> void: vol_master   = v; _apply_volumes()
func set_volume_bgm(v: float)      -> void: vol_bgm      = v; _apply_volumes()
func set_volume_sfx(v: float)      -> void: vol_sfx      = v; _apply_volumes()
func set_volume_ambience(v: float) -> void: vol_ambience = v; _apply_volumes()

# ── Convenience wrappers tied to game events ─────────────────────────────────
func on_footstep(surface: String) -> void:
    play_sfx("footstep_" + surface, 0.08)

func on_combat_hit() -> void:
    play_sfx("hit_impact", 0.10)
    play_sfx("hit_flesh",  0.12)

func on_gap_strike() -> void:
    play_sfx("gap_strike", 0.05)

func on_withdraw_call() -> void:
    play_sfx("withdraw_call", 0.0)

func on_sysnotif() -> void:
    play_ui("sysnotif_appear")

func on_inventory_unlock() -> void:
    play_ui("inventory_unlock")
    play_bgm("inventory_unlock_sting", 0.0)

func on_fate_title() -> void:
    stop_bgm(0.5)
    play_ui("fate_reveal")
    await get_tree().create_timer(0.8).timeout
    play_bgm("fate_title", 1.0)

func on_call_identified() -> void:
    play_ui("call_identify")

func on_enter_region(region: String) -> void:
    match region:
        "ashveld_day":
            play_bgm("ashveld_day"); play_ambience("wind_flats")
        "ashveld_night":
            play_bgm("ashveld_night"); play_ambience("wind_flats_night")
        "tribe_camp":
            play_bgm("tribe_camp"); play_ambience("campfire_ambient")
        "iron_chorus":
            play_bgm("iron_chorus"); play_ambience("forge_room")
        "caldenmere":
            play_bgm("caldenmere"); play_ambience("river_delta")
