# InventoryPanel.gd — Attach to the inventory PanelContainer
# Reads from GameManager autoload (inventory state, items, supply estimate)
extends PanelContainer

@onready var _locked_view  : Control = $MarginContainer/VBox/LockedView
@onready var _active_view  : Control = $MarginContainer/VBox/ActiveView
@onready var _status_label : Label   = $Header/HBox/StatusLabel
@onready var _slot_grid    : GridContainer = $MarginContainer/VBox/ActiveView/SlotGrid
@onready var _supply_label : Label   = $MarginContainer/VBox/ActiveView/Footer/SupplyLabel
@onready var _route_label  : Label   = $MarginContainer/VBox/ActiveView/Footer/RouteLabel

func _ready() -> void:
    GameManager.inventory_changed.connect(_refresh)
    _refresh()

func _refresh() -> void:
    var inv := GameManager.inventory
    if not inv.unlocked:
        _locked_view.show()
        _active_view.hide()
        _status_label.text = "LOCKED"
        return

    _locked_view.hide()
    _active_view.show()
    _status_label.text = "ACTIVE · Carrier: " + inv.carrier_name

    # Rebuild slot grid
    for child in _slot_grid.get_children():
        child.queue_free()

    for item in inv.items:
        var slot := preload("res://ui/components/InvSlot.tscn").instantiate()
        slot.set_item(item)
        _slot_grid.add_child(slot)

    # Empty slots
    for i in range(inv.capacity - inv.items.size()):
        var empty := preload("res://ui/components/InvSlot.tscn").instantiate()
        empty.set_empty()
        _slot_grid.add_child(empty)

    _supply_label.text = "supply: %.1f days · ±%.1f" % [
        inv.supply_days, inv.supply_confidence]
    _route_label.text = "route memory: %s · %d corridors" % [
        inv.carrier_root_stage, inv.corridors_logged]
