# SystemNotification.gd
# Attach to a PanelContainer node.
# Usage:  SystemNotification.show_notification("Inventory System: UNLOCKED")
#         SystemNotification.show_notification("Fate Title Generated: Sovereign Tide", true)
extends PanelContainer

const DISPLAY_DURATION = 4.0
const FADE_DURATION    = 0.6
const BLANK_COLOR      = Color(0.251, 0.235, 0.220, 1.0)  # slot 6 dashed accent

@onready var _tag   : Label = $VBox/Tag
@onready var _text  : Label = $VBox/Text
@onready var _sub   : Label = $VBox/Sub
@onready var _timer : Timer = $Timer

var _queue : Array[Dictionary] = []
var _busy  : bool = false

static var _instance : SystemNotification = null

func _ready() -> void:
    _instance = self
    hide()
    _timer.wait_time = DISPLAY_DURATION
    _timer.one_shot  = true
    _timer.timeout.connect(_on_timer_timeout)

static func show_notification(text: String,
                               sub_text: String = "",
                               is_blank_slot: bool = false) -> void:
    if _instance:
        _instance._enqueue(text, sub_text, is_blank_slot)

func _enqueue(text: String, sub: String, blank: bool) -> void:
    _queue.push_back({"text": text, "sub": sub, "blank": blank})
    if not _busy:
        _show_next()

func _show_next() -> void:
    if _queue.is_empty():
        _busy = false
        return
    _busy = true
    var data := _queue.pop_front() as Dictionary

    _tag.text  = "[ SYSTEM ]"
    _text.text = data["text"]
    _sub.text  = data["sub"]
    _sub.visible = data["sub"] != ""

    # Slot 6 uses dashed-border panel style via theme override
    if data["blank"]:
        _text.add_theme_color_override("font_color",
            Color(0.345, 0.337, 0.322, 1.0))
    else:
        _text.remove_theme_color_override("font_color")

    modulate.a = 0.0
    show()
    var tween := create_tween()
    tween.tween_property(self, "modulate:a", 1.0, FADE_DURATION)
    _timer.start()

func _on_timer_timeout() -> void:
    var tween := create_tween()
    tween.tween_property(self, "modulate:a", 0.0, FADE_DURATION)
    tween.tween_callback(func():
        hide()
        _show_next()
    )
