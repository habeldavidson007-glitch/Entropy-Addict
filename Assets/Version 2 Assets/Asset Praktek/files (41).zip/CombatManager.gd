# CombatManager.gd — Autoload for combat state
# Formation: Breaker + Striker + Anchor
# Auxiliary characters are NEVER added to combat — enforced here
extends Node

signal combat_started(enemies: Array)
signal combat_ended(result: String)
signal turn_changed(character: Dictionary)
signal log_updated(text: String)

const VALID_COMBAT_ROLES = ["Breaker", "Striker", "Anchor"]

var active_formation : Array[Dictionary] = []
var enemy_group      : Array[Dictionary] = []
var round_number     : int = 0
var current_turn     : int = 0
var is_active        : bool = false

func start_combat(enemies: Array) -> void:
    # Build formation from party — only combat roles
    active_formation.clear()
    for member in GameManager.party:
        if member.field_role in VALID_COMBAT_ROLES:
            active_formation.append(member)
    # Auxiliary characters silently excluded — correct per novel rules

    enemy_group   = enemies
    round_number  = 1
    current_turn  = 0
    is_active     = true
    combat_started.emit(enemies)
    _next_turn()

func _next_turn() -> void:
    if current_turn >= active_formation.size():
        current_turn = 0
        round_number += 1
    turn_changed.emit(active_formation[current_turn])

func execute_action(action: String) -> void:
    var actor := active_formation[current_turn]
    match action:
        "read":
            log_updated.emit("%s reads the fight." % actor.name)
        "gap_strike":
            # Striker-only action
            if actor.field_role != "Striker":
                log_updated.emit("Gap Strike: Striker role required.")
                return
            log_updated.emit("Gap Strike. Entered at the precise moment.")
            _resolve_attack(actor, true)
        "hold":
            log_updated.emit("%s holds the line." % actor.name)
        "withdraw":
            # Anchor signals withdrawal
            if actor.field_role == "Anchor":
                log_updated.emit("Withdrawal signal. Formation pulls back.")
                combat_ended.emit("withdraw")
            else:
                log_updated.emit("Only the Anchor makes the withdrawal call.")
        _:
            log_updated.emit("%s acts." % actor.name)
    current_turn += 1
    _next_turn()

func _resolve_attack(actor: Dictionary, is_special: bool) -> void:
    if enemy_group.is_empty(): return
    var target := enemy_group[0]
    var dmg := randi_range(3, 8) + (4 if is_special else 0)
    target["hp"] = max(0, target.get("hp", 20) - dmg)
    if target["hp"] <= 0:
        enemy_group.pop_front()
        log_updated.emit("Enemy down.")
    if enemy_group.is_empty():
        combat_ended.emit("victory")
