# CodexPanel.gd — Codex display for Jarger
# Slot 6 always renders as BLANK with dashed style
extends PanelContainer

const SLOT_SCENE = preload("res://ui/components/CodexSlot.tscn")
const BLANK_SLOT_IDX = 5  # zero-indexed

@onready var _slot_container : VBoxContainer = $ScrollContainer/VBox
@onready var _mastery_label  : Label = $Header/HBox/MasteryLabel

func _ready() -> void:
    GameManager.codex_changed.connect(_refresh)
    _refresh()

func _refresh() -> void:
    var codex := GameManager.codex
    _mastery_label.text = codex.primary + " · " + codex.secondary

    for child in _slot_container.get_children():
        child.queue_free()

    for i in range(6):
        var slot := SLOT_SCENE.instantiate()
        if i == BLANK_SLOT_IDX:
            slot.set_blank()
        elif i < codex.slots.size():
            slot.set_data(i + 1, codex.slots[i])
        else:
            slot.set_empty(i + 1)
        _slot_container.add_child(slot)
