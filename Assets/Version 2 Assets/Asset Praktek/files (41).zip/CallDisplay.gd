# CallDisplay.gd — Shows Call when Jarger identifies one
# Only Jarger can see Calls. No other character triggers this.
extends PanelContainer

const CALL_SCENE = preload("res://ui/components/CallCard.tscn")

@onready var _container : VBoxContainer = $ScrollContainer/VBox

func _ready() -> void:
    GameManager.call_identified.connect(_on_call_identified)

func _on_call_identified(character_data: Dictionary) -> void:
    # character_data: { name, call_text, tier, mastery, assessment, is_shifting }
    var card := CALL_SCENE.instantiate()
    card.set_call(character_data)
    _container.add_child(card)

    # System notification fires simultaneously
    SystemNotification.show_notification(
        "[ CALL IDENTIFIED ]",
        '"%s" · %s · Tier %d' % [
            character_data.call_text,
            character_data.mastery,
            character_data.tier
        ]
    )
