# VFXManager.gd
# Autoload — add to Project Settings > Autoloads as "VFX"
# Usage from anywhere: VFX.play("impact_flash", position)
extends Node

# ── Preloaded particle scenes ─────────────────────────────────────────────────
const SCENES := {
    "impact_flash"      : "res://vfx/scenes/ImpactFlash.tscn",
    "dust"              : "res://vfx/scenes/Dust.tscn",
    "ember"             : "res://vfx/scenes/Ember.tscn",
    "smoke"             : "res://vfx/scenes/Smoke.tscn",
    "hit_spark"         : "res://vfx/scenes/HitSpark.tscn",
    "water_ripple"      : "res://vfx/scenes/WaterRipple.tscn",
    "sysnotif_flash"    : "res://vfx/scenes/SysNotifFlash.tscn",
    "withdraw_signal"   : "res://vfx/scenes/WithdrawSignal.tscn",
    "footstep"          : "res://vfx/scenes/Footstep.tscn",
    "inventory_unlock"  : "res://vfx/scenes/InventoryUnlock.tscn",
    "call_shimmer"      : "res://vfx/scenes/CallShimmer.tscn",
    "fate_reveal"       : "res://vfx/scenes/FateReveal.tscn",
}

var _pool : Dictionary = {}   # scene_name -> Array[Node]
var _root : Node = null

func _ready() -> void:
    _root = get_tree().root
    # Pre-warm common effects
    for key in ["impact_flash", "dust", "hit_spark", "footstep"]:
        _pool[key] = []
        for i in range(3):
            _pool[key].append(_create(key))

# ── Public API ────────────────────────────────────────────────────────────────
func play(effect_name: String,
          world_pos: Vector2,
          parent: Node = null,
          scale: float = 1.0,
          modulate_col: Color = Color.WHITE) -> void:

    var node := _acquire(effect_name)
    if node == null:
        return

    var target_parent := parent if parent else get_tree().current_scene
    target_parent.add_child(node)

    node.global_position = world_pos
    node.scale            = Vector2(scale, scale)
    node.modulate         = modulate_col
    node.show()

    # GPUParticles2D: emit one burst
    if node is GPUParticles2D:
        node.restart()
        node.emitting = true
        # Auto-return after lifetime
        var timer := get_tree().create_timer(node.lifetime * 2.0)
        timer.timeout.connect(func(): _release(effect_name, node))
    # AnimatedSprite2D: play and return on finish
    elif node is AnimatedSprite2D:
        node.play("default")
        node.animation_finished.connect(
            func(): _release(effect_name, node), CONNECT_ONE_SHOT)

# Convenience wrappers matching novel events
func on_combat_hit(pos: Vector2) -> void:
    play("impact_flash", pos)
    play("hit_spark",    pos + Vector2(randf_range(-4,4), randf_range(-4,4)))

func on_gap_strike_land(pos: Vector2) -> void:
    play("impact_flash", pos, null, 1.6)
    play("hit_spark",    pos, null, 1.2)

func on_breakthrough(pos: Vector2) -> void:
    play("impact_flash", pos, null, 2.0)
    for i in range(4):
        var offset := Vector2(randf_range(-8,8), randf_range(-8,8))
        play("hit_spark", pos + offset)

func on_withdraw_call(pos: Vector2) -> void:
    play("withdraw_signal", pos, null, 1.0, Color(0.5, 0.75, 1.0))

func on_call_identified(character_node: Node2D) -> void:
    play("call_shimmer", character_node.global_position,
         character_node, 1.0)

func on_inventory_unlock(hud_pos: Vector2) -> void:
    play("inventory_unlock", hud_pos)
    play("sysnotif_flash",   hud_pos)

func on_fate_title(screen_center: Vector2) -> void:
    play("fate_reveal", screen_center, null, 1.0)

func on_footstep(pos: Vector2, direction: Vector2) -> void:
    var angle := direction.angle()
    var node := _acquire("footstep")
    if node == null: return
    get_tree().current_scene.add_child(node)
    node.global_position = pos
    node.rotation        = angle
    node.show()
    if node is GPUParticles2D:
        node.restart(); node.emitting = true
        var t := get_tree().create_timer(0.4)
        t.timeout.connect(func(): _release("footstep", node))

func on_ember_spawn(fire_pos: Vector2) -> void:
    play("ember", fire_pos + Vector2(randf_range(-3,3), 0))

func on_smoke_puff(pos: Vector2) -> void:
    play("smoke", pos)

# ── Pool management ───────────────────────────────────────────────────────────
func _acquire(name: String) -> Node:
    if _pool.has(name) and not _pool[name].is_empty():
        return _pool[name].pop_back()
    return _create(name)

func _release(name: String, node: Node) -> void:
    node.get_parent().remove_child(node) if node.get_parent() else null
    node.hide()
    if not _pool.has(name):
        _pool[name] = []
    _pool[name].push_back(node)

func _create(name: String) -> Node:
    if not SCENES.has(name):
        push_warning("VFXManager: unknown effect '%s'" % name)
        return null
    var packed := load(SCENES[name])
    if packed == null:
        push_warning("VFXManager: scene not found '%s'" % SCENES[name])
        return null
    var node : Node = packed.instantiate()
    node.hide()
    return node
