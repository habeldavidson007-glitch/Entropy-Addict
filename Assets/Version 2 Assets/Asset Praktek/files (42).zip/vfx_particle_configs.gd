# vfx_particle_configs.gd
# Reference file — NOT attached to a scene.
# Copy these parameter blocks when setting up each GPUParticles2D node
# in the Godot editor. Every value here corresponds to an Inspector field.

# ══════════════════════════════════════════════════════════════════════════════
# HOW TO USE THIS FILE:
# 1. Create a new scene (e.g. ImpactFlash.tscn)
# 2. Add GPUParticles2D as root node
# 3. In Inspector, set each property listed below
# 4. For "Process Material", create a new ParticleProcessMaterial
# 5. Save scene to res://vfx/scenes/
# ══════════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────────────────────
# IMPACT FLASH (ImpactFlash.tscn)
# Texture: res://vfx/textures/vfx_impact_flash_16x16.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 8
#   lifetime       = 0.25
#   one_shot       = true
#   explosiveness  = 1.0      # all particles burst at once
#   speed_scale    = 1.0
#
# ParticleProcessMaterial:
#   direction           = Vector3(0, -1, 0)
#   spread              = 180.0          # emit in all directions
#   initial_velocity_min = 20.0
#   initial_velocity_max = 60.0
#   gravity             = Vector3(0, 0, 0)
#   scale_min           = 0.5
#   scale_max           = 1.2
#   color               = Color(1, 1, 1, 1)
#   color_ramp:         white → transparent (use GradientTexture1D)

# ─────────────────────────────────────────────────────────────────────────────
# DUST (Dust.tscn)
# Texture: res://vfx/textures/vfx_dust_8x8.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 6
#   lifetime       = 0.5
#   one_shot       = true
#   explosiveness  = 0.8
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, -1, 0)
#   spread               = 60.0
#   initial_velocity_min = 8.0
#   initial_velocity_max = 20.0
#   gravity              = Vector3(0, 15, 0)   # slight fall
#   scale_min            = 0.8
#   scale_max            = 2.0
#   color                = Color(0.55, 0.51, 0.44, 0.7)

# ─────────────────────────────────────────────────────────────────────────────
# EMBER (Ember.tscn)
# Texture: res://vfx/textures/vfx_ember_4x4.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 3
#   lifetime       = 1.2
#   one_shot       = true
#   explosiveness  = 0.6
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, -1, 0)
#   spread               = 25.0
#   initial_velocity_min = 10.0
#   initial_velocity_max = 30.0
#   gravity              = Vector3(0, -5, 0)   # rise slightly
#   scale_min            = 0.8
#   scale_max            = 1.5
#   color_ramp:          orange → transparent

# ─────────────────────────────────────────────────────────────────────────────
# SMOKE (Smoke.tscn)
# Texture: res://vfx/textures/vfx_smoke_8x8.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 4
#   lifetime       = 1.8
#   one_shot       = true
#   explosiveness  = 0.4
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, -1, 0)
#   spread               = 30.0
#   initial_velocity_min = 5.0
#   initial_velocity_max = 15.0
#   gravity              = Vector3(0, -8, 0)
#   scale_min            = 1.0
#   scale_max            = 3.5              # smoke expands as it rises
#   color_ramp:          grey(0.6 alpha) → transparent

# ─────────────────────────────────────────────────────────────────────────────
# WATER RIPPLE (WaterRipple.tscn)
# Texture: res://vfx/textures/vfx_water_ripple_16x16.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 2
#   lifetime       = 0.8
#   one_shot       = true
#   explosiveness  = 1.0
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, 0, 0)
#   spread               = 0.0            # no spread — just expand in place
#   initial_velocity_min = 0.0
#   initial_velocity_max = 0.0
#   gravity              = Vector3(0, 0, 0)
#   scale_min            = 0.3
#   scale_max            = 0.3
#   scale_curve:         GrowCurve (0.3 → 1.5 over lifetime)
#   color_ramp:          visible → transparent

# ─────────────────────────────────────────────────────────────────────────────
# WITHDRAW SIGNAL (WithdrawSignal.tscn)
# Texture: res://vfx/textures/vfx_withdraw_signal_12x12.png
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 12
#   lifetime       = 0.6
#   one_shot       = true
#   explosiveness  = 1.0
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, -1, 0)
#   spread               = 180.0
#   initial_velocity_min = 30.0
#   initial_velocity_max = 80.0
#   gravity              = Vector3(0, 0, 0)
#   color                = Color(0.5, 0.75, 1.0, 1.0)   # Branec's blue
#   color_ramp:          blue-white → transparent

# ─────────────────────────────────────────────────────────────────────────────
# FATE REVEAL (FateReveal.tscn)
# Texture: res://vfx/textures/vfx_fate_reveal_32x32.png
# This is the biggest VFX moment in Arc 1 — Ch.015 Sovereign Tide
# ─────────────────────────────────────────────────────────────────────────────
# GPUParticles2D:
#   amount         = 16
#   lifetime       = 1.5
#   one_shot       = true
#   explosiveness  = 1.0
#
# ParticleProcessMaterial:
#   direction            = Vector3(0, -1, 0)
#   spread               = 180.0
#   initial_velocity_min = 10.0
#   initial_velocity_max = 40.0
#   gravity              = Vector3(0, 0, 0)
#   scale_min            = 0.8
#   scale_max            = 2.0
#   color                = Color(1.0, 0.85, 0.5, 1.0)   # warm gold
#   color_ramp:          gold → transparent
#
# ALSO ADD: AnimationPlayer to fade-in/out the whole node over 1.5s
