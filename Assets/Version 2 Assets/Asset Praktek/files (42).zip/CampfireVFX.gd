# CampfireVFX.gd
# Attach to the campfire object node (Sprite2D with campfire texture).
# Controls ember + smoke particles based on fire state (active / dead).
extends Node2D

@export var is_active : bool = true

@onready var _ember_particles : GPUParticles2D = $EmberParticles
@onready var _smoke_particles : GPUParticles2D = $SmokeParticles
@onready var _glow_light      : PointLight2D   = $GlowLight

var _ember_timer : float = 0.0
const EMBER_INTERVAL := 0.35

func _ready() -> void:
    set_fire_state(is_active)

func set_fire_state(active: bool) -> void:
    is_active = active
    _ember_particles.emitting = active
    _smoke_particles.emitting = active
    _glow_light.enabled       = active
    if active:
        _glow_light.energy    = 0.6
        _glow_light.color     = Color(1.0, 0.55, 0.15, 1.0)
    else:
        _glow_light.energy    = 0.0

func _process(delta: float) -> void:
    if not is_active:
        return
    _ember_timer += delta
    if _ember_timer >= EMBER_INTERVAL:
        _ember_timer = 0.0
        VFX.on_ember_spawn(global_position)
        if randf() < 0.3:
            VFX.on_smoke_puff(global_position + Vector2(0, -8))
    # Subtle glow flicker
    _glow_light.energy = lerp(_glow_light.energy,
        0.5 + randf() * 0.3, delta * 4.0)
