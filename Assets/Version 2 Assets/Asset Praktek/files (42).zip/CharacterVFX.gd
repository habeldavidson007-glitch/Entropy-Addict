# CharacterVFX.gd
# Attach to any character node that can walk and (for combat chars) fight.
# Handles footstep dust and combat VFX triggers.
extends Node

@export var is_combat_character : bool = false
@export var footstep_interval   : float = 0.4

var _step_timer    : float = 0.0
var _last_position : Vector2 = Vector2.ZERO
var _parent        : Node2D = null

func _ready() -> void:
    _parent = get_parent() as Node2D
    _last_position = _parent.global_position if _parent else Vector2.ZERO

func _process(delta: float) -> void:
    if _parent == null: return
    var moved := _parent.global_position.distance_to(_last_position)
    if moved > 1.0:
        _step_timer += delta
        if _step_timer >= footstep_interval:
            _step_timer = 0.0
            var dir := (_parent.global_position - _last_position).normalized()
            VFX.on_footstep(_parent.global_position, dir)
        _last_position = _parent.global_position

# Called by CombatManager when this character is hit
func trigger_hit() -> void:
    if _parent: VFX.on_combat_hit(_parent.global_position)

# Called by CombatManager when Jarger executes gap strike
func trigger_gap_strike(target_pos: Vector2) -> void:
    VFX.on_gap_strike_land(target_pos)

# Called when Branec signals withdraw
func trigger_withdraw() -> void:
    if _parent: VFX.on_withdraw_call(_parent.global_position)

# Called when Renk uses Breakthrough
func trigger_breakthrough(target_pos: Vector2) -> void:
    VFX.on_breakthrough(target_pos)
